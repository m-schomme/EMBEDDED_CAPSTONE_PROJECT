/* 
	Example rotating the relay and printing currrent/temperature
*/


#include <Arduino.h>
#include "HardwareAPI.h"


int counter = 0;

// Thermistor, Fan Relay, Fan Current, Peltier Relay, Peltier Current
HardwareAPI hardwareAPI = HardwareAPI(25, 26, 27, 32, 33);
// HardwareAPI hardwareAPI = HardwareAPI(true);  // Use for testing purposes

void setup() {
	Serial.begin(115200);
	hardwareAPI.turnFanOff();
	hardwareAPI.turnPeltierOff();

	hardwareAPI.setBaseADC();
}

void loop() {

	if (counter == 10) {
		hardwareAPI.toggleFan();
		hardwareAPI.togglePeltier();
		counter = 0;
		Serial.print("Toggled Fan, Status: ");
		Serial.println(hardwareAPI.getFanStatus());
		
		Serial.print("Toggled Peltier, Status: ");
		Serial.println(hardwareAPI.getPeltierStatus());
	}

	Serial.println("--------------");
	// Fan Current
	Serial.print("Fan Current: ");
	Serial.print(hardwareAPI.getFanCurrent(50), 3);
	Serial.println("A");
	// Fan Voltage (Kind of irrelevant, but could be used in the display)
	Serial.print("Fan Voltage: ");
	Serial.print(hardwareAPI.getFanVoltage());
	Serial.println("V");
	// Fan Power
	Serial.print("Fan Power: ");
	Serial.print(hardwareAPI.getFanPower(50), 3);
	Serial.println("W");
	// Peltier Current
	Serial.print("Peltier Current: ");
	Serial.print(hardwareAPI.getPeltierCurrent(50), 3);
	Serial.println("A");
	// Peltier Voltage (Kind of irrelevant, but could be used in the display)
	Serial.print("Peltier Voltage: ");
	Serial.print(hardwareAPI.getPeltierVoltage());
	Serial.println("V");
	// Peltier Power
	Serial.print("Peltier Power: ");
	Serial.print(hardwareAPI.getPeltierPower(50), 3);
	Serial.println("W");
	// Temperature
	Serial.print("Temperature: ");
	Serial.print(hardwareAPI.getTemperature(), 2);
	Serial.println(" degrees fahrenheit");
	
	Serial.println("--------------");

	delay(500);
	counter++;
}




